Maps made with Natural Earth. Free vector and raster map data @ naturalearthdata.com.
